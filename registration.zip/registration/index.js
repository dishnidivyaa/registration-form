const express = require("express");
const mongoose = require('mongoose');
const User = require('./model/User');
const bcrypt = require('bcrypt')
const path = require("path")
const dir = path.join(__dirname, "static")
const cors = require('cors')
const app = express();
app.use(cors());
app.use(express.static('static'));
app.use(express.json());

mongoose.connect("mongodb+srv://pitabaspradhan834:pitabasp934@cluster0.p6ocoqf.mongodb.net/registration?retryWrites=true&w=majority")
    .then(() => {
        console.log("Connected to database");
    })
    .catch((err) => {
        console.log(err);
    });

app.get("/", (req, resp) => {
    resp.sendFile(path.join(dir, "Registration.html"))
});

const corsOptions = {
    origin: 'http://localhost:5000',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,
};

app.post("/signup", cors(corsOptions), async (req, resp) => {
    console.log("Request Body:", req.body);
    try {
        const existingUser = await User.findOne({ email: req.body.email });

        if (existingUser) {
            return alert("email already there");
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(req.body.password, salt);

        const user = new User({
            username: req.body.username,
            email: req.body.email,
            password: hashedPassword,
        });

        await user.save();
        resp.status(201).json({ redirect: "/login.html" });
    } catch (err) {
        console.error("Error during signup:", err);
        resp.status(500).json({ error: "Internal Server Error" });
    }
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
